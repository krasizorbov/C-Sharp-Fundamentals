﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Concert
{
    class Program
    {
        static void Main(string[] args)
        {
            var band = new Dictionary<string, List<string>>();

            var bandAgain = new Dictionary<string, int>();

            string[] delimiters = new string[] { "; ", ", " };

            string[] input = Console.ReadLine().Split(delimiters, StringSplitOptions.RemoveEmptyEntries).ToArray();

            while (input[0] != "start of concert")
            {
                if (input[0] == "Add")
                {
                    var listofNames = new List<string>();
                    string bandName = input[1];
                    if (!band.ContainsKey(bandName))
                    {

                        for (int i = 2; i < input.Length; i++)
                        {
                            listofNames.Add(input[i]);
                        }
                        band.Add(bandName, listofNames);
                    }
                    else
                    {
                        for (int i = 2; i < input.Length; i++)
                        {
                            if (!band.Values.Any(x => x.Contains(input[i])))
                            {
                                band[bandName].Add(input[i]);
                            }
                        }
                    }
                }//if ends here.

                else if (input[0] == "Play")
                {
                    string bandName = input[1];
                    int playMin = int.Parse(input[2]);
                    if (!bandAgain.ContainsKey(bandName))
                    {
                        bandAgain.Add(bandName, playMin);
                    }
                    else
                    {
                        bandAgain[bandName] += playMin;
                    }
                }
                delimiters = new string[] { "; ", ", " };

                input = Console.ReadLine().Split(delimiters, StringSplitOptions.RemoveEmptyEntries).ToArray();

            }//while ends here.

            string lastBand = Console.ReadLine();

            Console.WriteLine($"Total time: {bandAgain.Values.Sum()}");

            foreach (var name in bandAgain.OrderByDescending(x => x.Value).ThenBy(x => x.Key))
            {
                Console.WriteLine($"{name.Key} -> {name.Value}");
            }

            foreach (var b in band)
            {
                if (b.Key == lastBand)
                {
                    Console.WriteLine(b.Key);
                    foreach (var name in b.Value)
                    {
                        Console.WriteLine($"=> {name}");
                    }
                }
            }
        }
    }
}
