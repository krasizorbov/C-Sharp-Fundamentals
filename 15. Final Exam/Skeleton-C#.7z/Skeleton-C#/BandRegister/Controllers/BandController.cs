﻿using BandRegister.Data;
using BandRegister.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace BandRegister.Controllers
{
    public class BandController : Controller
    {
        public IActionResult Index()
        {
            //TO DO
            using (var db = new BandDbContext())
            {
                var allTasks = db.Bands.ToList();
                return View(allTasks);
            }
            
        }

        [HttpGet]
        public IActionResult Create()
        {
            //TO DO
            return View();
        }

        [HttpPost]
        public IActionResult Create(string name, string genre, string members, decimal honorarium)
        {
            //TO DO
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(members) || honorarium <= 0)
            {
                return RedirectToAction("Index");
            }
            Band band = new Band
            {
                Name = name,
                Members = members,
                Genre = genre,
                Honorarium = honorarium
            };
            using (var db = new BandDbContext())
            {
                db.Bands.Add(band);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            //TO DO
            using (var db = new BandDbContext())
            {
                var taskToEdit = db.Bands.FirstOrDefault(t => t.Id == id);
                if (taskToEdit == null)
                {
                    return RedirectToAction("Index");
                }
                return View(taskToEdit);
            }
        }

        [HttpPost]
        public IActionResult Edit(Band band)
        {
            //TO DO
            if (!ModelState.IsValid)
            {
                return RedirectToAction("Index");
            }
            using (var db = new BandDbContext())
            {
                var taskToEdit = db.Bands.FirstOrDefault(t => t.Id == band.Id);
                taskToEdit.Name = band.Name;
                taskToEdit.Members = band.Members;
                taskToEdit.Genre = band.Genre;
                taskToEdit.Honorarium = band.Honorarium;
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            //TO DO
            using (var db = new BandDbContext())
            {
                var taskToDelete = db.Bands.FirstOrDefault(t => t.Id == id);
                if (taskToDelete == null)
                {
                    return RedirectToAction("Index");
                }
                db.Bands.Remove(taskToDelete);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Delete(Band band)
        {
            //TO DO
            return null;
        }
    }
}