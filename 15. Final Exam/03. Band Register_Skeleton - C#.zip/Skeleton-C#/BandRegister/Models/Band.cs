﻿using System.ComponentModel.DataAnnotations;

namespace BandRegister.Models
{
    public class Band
    {
        // TO DO
    }
}
